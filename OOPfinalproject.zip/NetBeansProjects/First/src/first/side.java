/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package first;

import static first.First.s;

public class side {
    public void mth(){
        
         System.out.println("welcome! the code starts here");
        //customer name
        String nem[] = new String[1];
        //initial deposit
        double dpo[] = new double[1];                
        System.out.print("Enter your name: ");
        nem[0] = s.nextLine();
        System.out.println("deposit");
        dpo[0] = s.nextDouble();        
        
        double div = 2/100;
        double mul = div*dpo[0];
        double ttl = dpo[0]+mul; 
        
        System.out.println("\nAccount Information");
        System.out.println("Name: " + nem[0]);
        System.out.println("Deposit: " + dpo[0]);
        System.out.println();
    
    
    }
}
