
package first;
import java.util.*;
public class First {
static Scanner s = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("welcome! the code starts here");
        
        String nem[] = new String[1];
        double dpo[] = new double[1];   
        for (int i = 0; i < 10; i++) {
            
        
        System.out.print("Enter your name: ");
        nem[0] = s.nextLine();
        System.out.println("deposit");
        dpo[0] = s.nextDouble();        
        double div;
        double mul;
        double tt;       
        if (dpo[0]>4999) {
        } else if(dpo[0]>5000){
        double div2 = 1/100;
        double mul2 = div2*dpo[0];
        double tt2 = dpo[0]+mul2;            
        } else if(dpo[0]>=5000 && dpo[0]<=19999){
        double div3 = 2/100;
        double mul3 = div3*dpo[0];
        double ttl = dpo[0]+mul3;                           
        } else if(dpo[0]>=20000 && dpo[0]<=49999){
        double div4 = 3/100;
        double mul4 = div4*dpo[0];
        double tt4 = dpo[0]+mul4; 
        
        
        }else if(dpo[0]>=50000){
        double div5 = 5/100;
        double mul5 = div5*dpo[0];
        double tt5 = dpo[0]+mul5; 
        System.out.println("\nAccount Information");
        System.out.println("Name: " + nem[0]);
        System.out.println("Deposit: " + dpo[0]); 
        System.out.println("");
        }
        }        
        //output
              
        
        
        
        
        
        
        
        
        
      

        

        

        

        
   
        
        
        
    }
    
}
