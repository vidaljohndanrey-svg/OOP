
package javaapplication7;
public class JavaApplication7 {
/*
    Character CH = new Character();
        CH.info();
        CH.newLife();

    
    
    
    
public void newLife() {
        System.out.print("How did you die? \nA. Invitation"
                                        + "\nB. natural death"
                                        + "\nC. By Accident\n");       
        while (true) {
        String Charac;
        char O = s.next().charAt(0);
     
        switch (O) {
            case 'A':
            case 'a':
                System.out.println("You chose the first option: A "
                        + "\nCongratulations, You are hereby declared as a hero"
                        + "\nyou get to choose your own 3 skills/passive"
                        + "\noffense/defense/special");                
 
                   s.nextLine();
                FS = s.nextLine();
                ss = s.nextLine();
                SPS = s.nextLine();
                System.out.println("your name is "+NM+"\n"+age+"\n"+Pl);
                System.out.println("your ability is "+FS+"\n"+ss+"\n"+SPS
                        + "\nyour destination is: newWorld");
                System.out.println("Goodluck, hero");
                System.exit(0);
                break;

            case 'B':
            case 'b':
                System.out.println("You chose the third option: B"
                        + "Congratulations! \nyou are an NPC. you have been given a chance to live another life"
                        + "\nyou will be reborn without your memories into the newWorld"
                        + "\nyou have one wish\n");
                s.nextLine();
                 String FW = s.nextLine();
                 System.out.println("your name is: "+NM+"\nyour age: "+age+"\nyour origin place: "+Pl);
                 System.out.println("your wish is: "+"\n=======\n"+FW+"\n=======");
                 System.out.println("\nGoodluck, "+NM);
                 System.exit(0);
                break;
            
            case 'C':
            case 'c':
                System.out.println("You chose the final option: C"
                        + "\nyou have been mistakenly killed by the reaper"
                        + "\nas an apology, you are to be transfered into the new world and one wish"
                        + "\nyou have no responsibility, you are free to do as you please"
                        + "\nyour wish is?: ");
                s.nextLine();
                String OW = s.nextLine();
                System.out.println("your name is: "+NM+"\nyour age: "+age+"\nyour origin place: "+Pl);
                System.out.println("your wish is: "+"\n=======\n"+OW+"\n=======");
                System.out.println("\nGoodluck, "+NM);
                System.exit(0);
                break;
                
            default:
                System.out.println("Invalid option.");
        }
        }
          
    }

    
    
    
    
    
    
    
    
    
    
    
    mport java.util.Scanner;

public class Character {
    static Scanner s = new Scanner(System.in);

    String NM;
    String age;
    String Pl;
    String FS;
    String ss;

    public Character() {
        System.out.print("State your name: ");
        NM = s.nextLine();

        System.out.print("Age: ");
        age = s.nextLine();

        System.out.print("Place you are from: ");
        Pl = s.nextLine();

        System.out.print("FS: ");
        FS = s.nextLine();

        System.out.print("SS: ");
        ss = s.nextLine();
    }

    public void info() {
        System.out.println("Name: " + NM);
        System.out.println("Age: " + age);
        System.out.println("Place: " + Pl);
        System.out.println("FS: " + FS);
        System.out.println("SS: " + ss);
    }
}





public class Continent {

    public static void main(String[] args) {

        Character Ch1 = new Character();
        Character Ch2 = new Character();
        Character Ch3 = new Character();

        Character[] ch = {Ch1, Ch2, Ch3};

        ch[0].info();
        ch[1].info();
        ch[2].info();
    }
}

    
  */  
}
