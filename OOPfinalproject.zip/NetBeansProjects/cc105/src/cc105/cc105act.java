package cc105;
import java.util.*;
public class cc105act {
     static Scanner s = new Scanner(System.in);
     
         // The user enters the maximum number of elements the stack can hold.
    final static int MAXSIZE = s.nextInt();

    public static int stack[] = new int[MAXSIZE];
    public static int top = -1;
    static String opt;

    // Checks whether the stack currently has no elements.
    public static int isempty() {
        if (top == -1)
            return 1;
        else
            return 0;
    }

    // Checks whether the stack has reached its maximum capacity.
    public static int isfull() {
        if (top == MAXSIZE - 1)
            return 1;
        else
            return 0;
    }

    // Returns the element currently at the top without removing it.
    public static int peek() {
        if (isempty() != 1)
            return stack[top];
        else {
            System.out.print("Could not retrieve data, Stack is empty.");
            return 0;
        }
    }

    // Removes and returns only the top element of the stack.
    public static int pop() {
        int data = 0;

        if (isempty() != 1) {
            data = stack[top];
            top = top - 1;
            return data;
        }
        else {
            System.out.print("Could not retrieve data, Stack is empty.");
            return data;
        }
    }

    // Adds one element to the top of the stack as long as it is not full.
    public static int push(int data) {
        if (isfull() != 1) {
            top = top + 1;
            stack[top] = data;
            System.out.println("Data pushed successfully.");
        }
        else {
            System.out.print("Could not insert data, Stack is full.");
        }
        return data;
    }

    // Main function controls the menu and allows stack operations to
    // continue until the user chooses to exit.
    public static void main(String[] args) {

        s.nextLine();
        int choice;

        while (true) {

            System.out.println("\n===== MENU =====");
            System.out.println("1 push");
            System.out.println("2 peek");
            System.out.println("3 pop");
            System.out.println("4 display");
            System.out.println("5. Exit");
            System.out.print("Choose: ");
            choice = s.nextInt();

            switch (choice) {

                case 1:
                    // Pushes one number at a time. After the operation,
                    // the program returns to the menu for another choice.
                    System.out.println("You chose push");
                    System.out.print("Insert a number: ");
                    push(s.nextInt());

                    break;

                case 2:
                    // Shows the top element without removing it from the stack.
                    System.out.println("You chose peek");

                    if (isempty() != 1)
                        System.out.println("Element at top of the stack: " + peek());
                    else
                        System.out.println("Stack is empty.");

                    break;

                case 3:
                    // Removes only one element from the top of the stack.
                    // The remaining elements stay in the stack.
                    System.out.println("You chose pop");

                    if (isempty() != 1)
                        System.out.println("Removed element: " + pop());
                    else
                        System.out.println("Stack is empty.");

                    break;

                case 4:
                    // Displays all elements without removing them.
                    // The loop starts from the top and moves downward,
                    // preserving the contents of the stack.
                    System.out.println("You chose to display");

                    if (isempty() == 1) {
                        System.out.println("Stack is empty.");
                    }
                    else {
                        System.out.println("\nElements:");

                        for (int i = top; i >= 0; i--) {
                            System.out.print(stack[i] + " ");
                        }

                        System.out.println();
                    }

                    break;

                case 5:
                    // Ends the program without changing or removing
                    // anything from the stack.
                    System.out.println("Thank you!");
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
