package OOP;

import java.util.Scanner;

public class Chrctr {

    static Scanner s = new Scanner(System.in);
    String NM;
    String age;
    String Pl;
    String FS;
    String ss;

    public Chrctr(String NM, String age) {
        this.NM = NM;
        this.age = age;
    }

}

//    public static void Create(){
//        System.out.println("123456789");        
//        Character ch = new Character(s.nextLine(), s.nextLine(), s.nextLine(), s.nextLine(), s.nextLine());
//        System.out.println("123456789");
//
//    }

