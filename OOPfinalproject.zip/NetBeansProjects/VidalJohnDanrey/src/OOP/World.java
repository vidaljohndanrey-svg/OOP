package OOP;

public class World {

    public static void main(String[] args) {
        Continent cn = new Continent();
        cn.newLife();

    }
}
