package OOP;

import java.util.Scanner;

public class Continent {

    static Scanner s = new Scanner(System.in);

    public void newLife() {
        System.out.println("\n"
                + "\nwelcome to afterlife");
        Chrctr CH = null;
        Chrctr CH2 = null;
        Chrctr[] ch = {CH, CH2, null};
        char u;
        char ort;

        do {
            System.out.println(""
                    + "\nchoose A to create a character, choose B to add two skills for your character, choose C view your character and choose D to exit\n"
                    + "");
            u = s.next().charAt(0);
            s.nextLine();

            switch (u) {
                case 'A':
                case 'a':
                    System.out.println("A. first character or B. second character");
                    ort = s.next().charAt(0);
                    s.nextLine();
                    switch (ort) {
                        case 'A':
                        case 'a':
                            System.out.println("enter your first character's name and age");
                            CH = new Chrctr(s.nextLine(), s.nextLine());
                            ch[0] = CH;
                            System.out.println("Name and age has been added");
                            break;
                        case 'B':
                        case 'b':
                            System.out.println("enter your second character's name, age");
                            CH2 = new Chrctr(s.nextLine(), s.nextLine());
                            ch[1] = CH2;
                            System.out.println("Name and age has been added");
                            break;
                    }
                    break;

                case 'B':
                case 'b':
                    if (ch[0] == null && ch[1] == null) {
                        System.out.println("No Character.\nCreate the character first. choose A to create a character.");
                    } else if (ch[0] != null && ch[1] != null) {
                        System.out.println("A. first character or B. second character");
                        ort = s.next().charAt(0);
                        s.nextLine();   // fixed
                        switch (ort) {
                            case 'A':
                            case 'a':
                                System.out.println("enter planet, First skill, Special skill for your first character");
                                System.out.println("Planet: ");
                                ch[0].Pl = s.nextLine();
                                System.out.println("First skill: ");
                                ch[0].FS = s.nextLine();
                                System.out.println("Special skill: ");
                                ch[0].ss = s.nextLine();
                                System.out.println("Destination and Skills added.");
                                break;
                            case 'B':
                            case 'b':
                                System.out.println("enter planet, First skill, Special skill for your second character");
                                System.out.println("Planet: ");
                                ch[1].Pl = s.nextLine();
                                System.out.println("First skill: ");
                                ch[1].FS = s.nextLine();
                                System.out.println("Special skill: ");
                                ch[1].ss = s.nextLine();
                                System.out.println("Destination and Skills added.");
                                break;
                        }
                    } else {
                        System.out.println("Finish creating both characters");
                    }
                    break;

                case 'C':
                case 'c':
                    if (ch[0] == null && ch[1] == null) {
                        System.out.println("No character created yet.");
                    } else if (ch[0] != null && ch[1] != null) {
                        System.out.println("A. First Character or B. second character");
                        ort = s.next().charAt(0);
                        s.nextLine();   // fixed
                        switch (ort) {
                            case 'A':
                            case 'a':
                                System.out.println("first character");
                                System.out.println("Name: " + ch[0].NM
                                        + "\nAge: " + ch[0].age
                                        + "\nDestination: " + ch[0].Pl
                                        + "\nFirst skill: " + ch[0].FS
                                        + "\nSpecial skill: " + ch[0].ss);
                                break;
                            case 'B':
                            case 'b':
                                System.out.println("second character: ");
                                System.out.println("Name: " + ch[1].NM
                                        + "\nAge: " + ch[1].age
                                        + "\nDestination: " + ch[1].Pl
                                        + "\nFirst skill: " + ch[1].FS
                                        + "\nSpecial skill: " + ch[1].ss);
                                break;
                        }
                    } else {
                        System.out.println("finish creating both characters");
                    }
                    break;

                case 'D':
                case 'd':
                    System.out.println("are you sure? yes or no?");
                    ort = s.next().charAt(0);
                    s.nextLine();   // fixed
                    switch (ort) {
                        case 'Y':
                        case 'y':
                            System.exit(0);
                            break;
                        case 'N':
                        case 'n':
                            break;
                    }
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        } while (u != 'D' && u != 'd');

    }
}
