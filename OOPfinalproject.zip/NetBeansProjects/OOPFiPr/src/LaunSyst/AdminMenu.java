package LaunSyst;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AdminMenu {
    public static void main(String[] args) {
        JFrame frame = new JFrame(); //"LAUNDRY BILLING SYSTEM - ADMIN"
        JLabel Adac = new JLabel("Admin Access");
        JLabel logtxt = new JLabel("LAUNDRY BILLING SYSTEM");
        JLabel bet = new JLabel("Better Service");
        JLabel bri = new JLabel("Brighter Days");
        JLabel logln = new JLabel("Clean Clothes - Fresh Life");
        JLabel ver = new JLabel("Version 1.8");
        JButton lgout = new JButton("Log Out                     >");
        JButton Trahis = new JButton("Transaction History     >");
        
        frame.setTitle("LAUNDRY BILLING SYSTEM - ADMIN");
        frame.setBackground(Color.blue);
                //admin access
        frame.add(Adac);
        Adac.setFont(new Font("Arial", Font.BOLD, 20));
        Adac.setForeground(Color.blue);
        Adac.setBounds(90, 685, 180, 30);
                //clean clothes
        frame.add(logln);
        logln.setFont(new Font("Segoe Script", Font.BOLD, 28));
        logln.setForeground(Color.blue);
        logln.setBounds(160, 438, 440, 45);
                //tittle
        frame.add(logtxt);
        logtxt.setFont(new Font("Arial", Font.BOLD, 48));
        logtxt.setForeground(Color.blue);
        logtxt.setBounds(45, 365, 655, 65);
                //better service
        frame.add(bet);
        bet.setFont(new Font("Segoe Script", Font.BOLD, 20));
        bet.setForeground(Color.blue);
        bet.setBounds(1090, 615, 270, 90);
                //brighter days
        frame.add(bri);
        bri.setFont(new Font("Segoe Script", Font.BOLD, 20));
        bri.setForeground(Color.blue);
        bri.setBounds(1090, 645, 270, 90);
                //version 1.8
        frame.add(ver);
        ver.setFont(new Font("Arial", Font.BOLD, 16));
        ver.setForeground(Color.blue);
        ver.setBounds(90, 718, 120, 25);
                //log out
        frame.add(lgout);
        lgout.setFont(new Font("Arial", Font.BOLD, 28));
        lgout.setBackground(Color.red);
        lgout.setBounds(742, 249, 619, 128);
                //transaction history
        frame.add(Trahis);
        Trahis.setFont(new Font("Arial", Font.BOLD, 28));
        Trahis.setBackground(Color.blue);
        Trahis.setBounds(742, 81, 619, 128);
        
        frame.setLayout(null);
        frame.setResizable(true);
        frame.setSize(1400, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
//        JFrame frame = new JFrame(); //"LAUNDRY BILLING SYSTEM - ADMIN"
//        JLabel Adac = new JLabel("Admin Access");
//        JLabel logtxt = new JLabel("LAUNDRY BILLING SYSTEM");
//        JLabel bet = new JLabel("Better Service");
//        JLabel bri = new JLabel("Brighter Days");
//        JLabel logln = new JLabel("Clean Clothes - Fresh Life");
//        JLabel ver = new JLabel("Version 1.8");
//        JButton bck = new JButton("Log Out                     >");
//        JButton login = new JButton("Transaction History     >");
//        
//        frame.setTitle("LAUNDRY BILLING SYSTEM - ADMIN");
//        frame.setBackground(Color.blue);
//                //admin access
//        frame.add(Adac);
//        Adac.setFont(new Font("Arial", Font.BOLD, 20));
//        Adac.setForeground(Color.blue);
//        Adac.setBounds(90, 685, 180, 30);
//                //clean clothes
//        frame.add(logln);
//        logln.setFont(new Font("Segoe Script", Font.BOLD, 28));
//        logln.setForeground(Color.blue);
//        logln.setBounds(160, 438, 440, 45);
//                //tittle
//        frame.add(logtxt);
//        logtxt.setFont(new Font("Arial", Font.BOLD, 48));
//        logtxt.setForeground(Color.blue);
//        logtxt.setBounds(45, 365, 655, 65);
//                //better service
//        frame.add(bet);
//        bet.setFont(new Font("Segoe Script", Font.BOLD, 20));
//        bet.setForeground(Color.blue);
//        bet.setBounds(1090, 615, 270, 90);
//                //brighter days
//        frame.add(bri);
//        bri.setFont(new Font("Segoe Script", Font.BOLD, 20));
//        bri.setForeground(Color.blue);
//        bri.setBounds(1090, 645, 270, 90);
//                //version 1.8
//        frame.add(ver);
//        ver.setFont(new Font("Arial", Font.BOLD, 16));
//        ver.setForeground(Color.blue);
//        ver.setBounds(90, 718, 120, 25);
//                //log out
//        frame.add(bck);
//        bck.setFont(new Font("Arial", Font.BOLD, 28));
//        bck.setBackground(Color.red);
//        bck.setBounds(742, 249, 619, 128);
//                //transaction history
//        frame.add(login);
//        login.setFont(new Font("Arial", Font.BOLD, 28));
//        login.setBackground(Color.blue);
//        login.setBounds(742, 81, 619, 128);
//        
//        frame.setLayout(null);
//        frame.setResizable(true);
//        frame.setSize(1400, 800);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setLayout(null);
//        frame.setVisible(true);
//        frame.setLocationRelativeTo(null);    
//      

    
            
//        JLabel passlbl = new JLabel("user password");
//        JLabel uselbl = new JLabel("user name");
//        JTextField user = new JTextField();
//        JTextField pass = new JTextField();
//        String username = user.getText();
//        String password = pass.getText();
//        
//        frame.add(passlbl);
//        passlbl.setBounds(80, 70, 100, 25);
//        frame.add(uselbl);
//        uselbl.setBounds(80, 35, 100, 25);
//        frame.add(user);
//        user.setBounds(180, 35, 220, 25);
//        frame.add(pass);
//        pass.setBounds(180, 70, 220, 25);
//        
//        frame.setLayout(null);
//        frame.setResizable(true);
//        frame.setSize(500, 200);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setLayout(null);
//        frame.setVisible(true);
//        frame.setLocationRelativeTo(null);
//        
        

    }


