package LaunSyst;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login {   

    public static void main(String[] args) { 
        
        JFrame frame = new JFrame(); 
        JPanel panel = new JPanel();
        JPanel swpanel = new JPanel();
        JPanel wpanel = new JPanel();
        JPanel tb = new JPanel();
        JLabel ttl = new JLabel("LAUNDRY BILLING SYSTEM - EMPLOYEE");
        JLabel logln = new JLabel("Welcome! please login to continue");
        JButton bck = new JButton("Back to Main Menu");
        JButton login = new JButton("-> Log In");
        JButton cl = new JButton("x");
        JButton mn = new JButton("-");
        JButton mx = new JButton("□");
        
        
        JLabel adlg = new JLabel("EMPLOYEE LOGIN");
        JLabel passlbl = new JLabel("Password      (Enter Password)");
        JLabel uselbl = new JLabel("Username    (Enter Username)");
        JTextField user = new JTextField();
        JTextField pass = new JTextField();
        String username = user.getText();
        String password = pass.getText();
        
                //white background
        panel.setBounds(0, 40, 1399, 799);
        panel.setBackground(Color.white);
        frame.add(panel);
        panel.setLayout(null);
        panel.setVisible(true);
                //blue panel
        swpanel.setBounds(200, 50, 975, 650);
        swpanel.setBackground(Color.blue);
        panel.add(swpanel);
        swpanel.setLayout(null);
        swpanel.setVisible(true);
                //white panel
        wpanel.setBounds(5, 5, 965, 640);
        wpanel.setBackground(Color.white);
        swpanel.add(wpanel);
        wpanel.setLayout(null);
        wpanel.setVisible(true);
                //title bar
        frame.setUndecorated(true);
        tb.setBackground(new Color(0, 102, 204));
        tb.setBounds(0, 0, 1400, 40);
        tb.setLayout(null);
        ttl.setForeground(Color.WHITE);
        ttl.setFont(new Font("Arial", Font.BOLD, 18));
        ttl.setBounds(15, 5, 400, 30);
        tb.add(ttl);
        frame.add(tb);
                //buttons
                //minimize button
        tb.add(mn);
        mn.setBounds(1250, 0, 50, 40);
        mn.setBorderPainted(false);
        mn.setForeground(Color.WHITE);
        mn.setBackground(new Color(0, 102, 204));
        mn.setFocusPainted(false);
                //maximize button
        tb.add(mx);
        mx.setBounds(1300, 0, 50, 40);
        mx.setBorderPainted(false); 
        mx.setForeground(Color.WHITE);
        mx.setBackground(new Color(0, 102, 204));
        mx.setFocusPainted(false);
                //close button
        tb.add(cl);
        cl.setBounds(1350, 0, 50, 40);
        cl.setBorderPainted(false);
        cl.setBackground(Color.RED);
        cl.setForeground(Color.WHITE);
        cl.setFocusPainted(false);
                //welcome
        wpanel.add(logln);
        logln.setFont(new Font("Segoe Script", Font.BOLD, 28));
        logln.setForeground(Color.blue);
        logln.setBounds(210, 60, 570, 45);
                 //back
        wpanel.add(bck);
        bck.setFont(new Font("Arial", Font.BOLD, 26));
        bck.setBackground(Color.red);
        bck.setBounds(220, 525, 515, 60);
                //login
        wpanel.add(login);
        login.setFont(new Font("Arial", Font.BOLD, 30));
        login.setBackground(Color.blue);
        login.setBounds(220, 440, 515, 70);

        //emp log
        wpanel.add(adlg);
        adlg.setFont(new Font("Arial", Font.BOLD, 42));
        adlg.setBackground(Color.blue);
        adlg.setBounds(310, 0, 650, 55);
        //pass
        wpanel.add(passlbl);
        passlbl.setFont(new Font("Arial", Font.BOLD, 28));
        passlbl.setBackground(Color.blue);
        passlbl.setBounds(220, 290, 500, 40);
        //user
        wpanel.add(uselbl);
        uselbl.setFont(new Font("Arial", Font.BOLD, 28));
        uselbl.setBackground(Color.blue);
        uselbl.setBounds(220, 150, 500, 40);
        //textfields
        wpanel.add(user);
        user.setBounds(220, 195, 515, 60);
        wpanel.add(pass);
        pass.setBounds(220, 335, 515, 60);

        
        frame.setLayout(null);
        frame.setResizable(true);
        frame.setSize(1400, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);    
                                              
                //actionlistener for close, minimize and maximize
                //close
              cl.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
             frame.dispose();
          }
        });
        cl.addActionListener(e -> {
          frame.dispose();
        });
                //minimize
              mn.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
              frame.setState(JFrame.ICONIFIED);
          }
        });
//                //maximize
//               mx.addActionListener(new ActionListener() {
//           public void actionPerformed(ActionEvent e) {
//             if (frame.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
//                  frame.setExtendedState(JFrame.NORMAL);
//          } else {
//            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
//              }
//            }
//        });

                

    }
}
