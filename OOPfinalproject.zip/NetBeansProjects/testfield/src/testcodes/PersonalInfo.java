
package testcodes;
import java.util.Scanner;
public class PersonalInfo {
    Scanner sc = new Scanner(System.in);

    String name;
    int age;
    String address;
    String gender;
    String course;

    public void inputInfo() {
        System.out.print("Enter Name: ");
        name = sc.nextLine();

        System.out.print("Enter Age: ");
        age = sc.nextInt();
        sc.nextLine(); // Clears the newline

        System.out.print("Enter Address: ");
        address = sc.nextLine();

        System.out.print("Enter Gender: ");
        gender = sc.nextLine();

        System.out.print("Enter Course: ");
        course = sc.nextLine();
    }

    public void displayInfo() {
        System.out.println("\n===== PERSONAL INFORMATION =====");
        System.out.println("Name    : " + name);
        System.out.println("Age     : " + age);
        System.out.println("Address : " + address);
        System.out.println("Gender  : " + gender);
        System.out.println("Course  : " + course);
    }
}

