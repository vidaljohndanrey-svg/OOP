
package testcodes;

public class HallOfRebirth {
    public static void main(String[] args) {

        PersonalInfo person = new PersonalInfo();

        person.inputInfo();
        person.displayInfo();

    }
}
