
package OOP;
import java.util.Scanner;
public class Character {
    String NM;
    int age;
    String Pl;
    String FS;
    String ss;
    String SPS;
Scanner s = new Scanner(System.in);
    public String info() {
      System.out.println("State your name: ");
        NM = s.nextLine();
        System.out.println("age: ");
        age = s.nextShort();
        System.out.println("Place you are from: ");
        s.nextLine();
        Pl = s.nextLine();   
        return "";
    }
    
    
    
    
    public void newLife() {
        System.out.print("How did you die? \nA. Invitation"
                                        + "\nB. natural death"
                                        + "\nC. By Accident\n");       
        while (true) {
        String Charac;
        char O = s.next().charAt(0);
     
        switch (O) {
            case 'A':
            case 'a':
                System.out.println("You chose the first option: A "
                        + "\nCongratulations, You are hereby declared as a hero"
                        + "\nyou get to choose your own 3 skills/passive"
                        + "\noffense/defense/special");                
 
                   s.nextLine();
                FS = s.nextLine();
                ss = s.nextLine();
                SPS = s.nextLine();
                System.out.println("your name is "+NM+"\n"+age+"\n"+Pl);
                System.out.println("your ability is "+FS+"\n"+ss+"\n"+SPS
                        + "\nyour destination is: newWorld");
                System.out.println("Goodluck, hero");
                System.exit(0);
                break;

            case 'B':
            case 'b':
                System.out.println("You chose the third option: B"
                        + "Congratulations! \nyou are an NPC. you have been given a chance to live another life"
                        + "\nyou will be reborn without your memories into the newWorld"
                        + "\nyou have one wish\n");
                s.nextLine();
                 String FW = s.nextLine();
                 System.out.println("your name is: "+NM+"\nyour age: "+age+"\nyour origin place: "+Pl);
                 System.out.println("your wish is: "+"\n=======\n"+FW+"\n=======");
                 System.out.println("\nGoodluck, "+NM);
                 System.exit(0);
                break;
            
            case 'C':
            case 'c':
                System.out.println("You chose the final option: C\n"
                        + "you have been mistakenly killed by the reaper"
                        + "as an apology, you are to be transfered into the new world and one wish"
                        + "you have no responsibility, you are free to do as you please"
                        + "your wish is?: ");
                s.nextLine();
                String OW = s.nextLine();
                System.out.println("your name is: "+NM+"\nyour age: "+age+"\nyour origin place: "+Pl);
                System.out.println("your wish is: "+"\n=======\n"+OW+"\n=======");
                System.out.println("\nGoodluck, "+NM);
                System.exit(0);
                break;
                
            default:
                System.out.println("Invalid option.");
        }
        }
          
    }
    }
