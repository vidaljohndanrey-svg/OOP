
package DSAact;
import java.util.Scanner;
public class ThriSrt {
    public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int[] no = new int[5];
    for (int i = 0; i < 5; i++) {
      System.out.print("Enter number " + (i + 1) + ": ");
     no[i] = s.nextInt();
 }
    System.out.print("Enter target value: ");
    int t = s.nextInt();
    System.out.println("\nChoose a sorting algorithm:");
   System.out.println("1 - Bubble Sort");
    System.out.println("2 - Selection Sort");
    System.out.println("3 - Insertion Sort");
    System.out.print("Enter your choice: ");
    int choice = s.nextInt();
    switch (choice) {
       case 1:
         for (int i = 0; i < no.length - 1; i++) {
         for (int j = 0; j < no.length - 1 - i; j++) {
         if (no[j] > no[j + 1]) {
         int temp = no[j];
             no[j] = no[j + 1];
             no[j + 1] = temp;
}
      }
   }
    break;
     case 2:
        for (int i = 0; i < no.length - 1; i++) {
          int min = i;
         for (int j = i + 1; j < no.length; j++) {
            if (no[j] < no[min]) {
               min = j;
  }
 }
   int temp = no[i];
           no[i] = no[min];
           no[min] = temp;
 }
      break;
  case 3:
    for (int i = 1; i < no.length; i++) {
     int key = no[i];
     int j = i - 1;
      while (j >= 0 && no[j] > key) {
      no[j + 1] = no[j];
      j--;
     }
     no[j + 1] = key;
 }
      break;
      default:
      System.out.println("Invalid choice!");
      s.close();
      return;
   }
      System.out.print("\nSorted numbers: ");
     for (int i = 0; i < no.length; i++) {
        System.out.print(no[i] + " ");
        }
        boolean a = false;

        for (int i = 0; i < no.length; i++) {
            
        if (no[i] == t) {
         a = true;
          break;
                
                
            }
        }
    if (a) {
      System.out.println("\nTarget value found!");
    } else {
     System.out.println("\nTarget value not found.");
   }
 }
}    

